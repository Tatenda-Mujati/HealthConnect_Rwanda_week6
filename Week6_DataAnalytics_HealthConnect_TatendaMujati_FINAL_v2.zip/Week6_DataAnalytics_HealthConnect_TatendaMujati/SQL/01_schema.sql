-- =====================================================================
-- HealthConnect Rwanda | Healthcare Operations & Performance Analytics
-- 01_schema.sql  -  PostgreSQL 16 schema (tables, keys, indexes, views)
-- Run order: 01_schema.sql -> 02_load_data.sql -> 03_validation_checks.sql -> 04_analysis_queries.sql
-- =====================================================================
DROP SCHEMA IF EXISTS hc CASCADE;
CREATE SCHEMA hc;
SET search_path = hc, public;

-- ---------- Geography ----------
CREATE TABLE countries (country_id VARCHAR(8) PRIMARY KEY, country_name TEXT NOT NULL, country_code VARCHAR(4), iso_code VARCHAR(4), currency VARCHAR(4), region TEXT);
CREATE TABLE provinces (province_id VARCHAR(8) PRIMARY KEY, province_name TEXT NOT NULL, country_id VARCHAR(8) NOT NULL REFERENCES countries);
CREATE TABLE districts (district_id VARCHAR(8) PRIMARY KEY, district_name TEXT NOT NULL, province_id VARCHAR(8) NOT NULL REFERENCES provinces);
CREATE TABLE sectors   (sector_id   VARCHAR(8) PRIMARY KEY, sector_name   TEXT NOT NULL, district_id VARCHAR(8) NOT NULL REFERENCES districts);
CREATE TABLE villages  (village_id  VARCHAR(8) PRIMARY KEY, village_name  TEXT NOT NULL, sector_id   VARCHAR(8) NOT NULL REFERENCES sectors);
CREATE TABLE ownership_types (ownership_id VARCHAR(8) PRIMARY KEY, ownership_type TEXT NOT NULL);

-- ---------- Facility structure ----------
-- NOTE: the Health Facilities master (name/type/ownership/location) was NOT supplied.
-- Facilities are therefore identified by FacilityID only (derived from Departments).
CREATE TABLE facilities (facility_id VARCHAR(8) PRIMARY KEY);
CREATE TABLE departments (department_id VARCHAR(8) PRIMARY KEY, department_name TEXT NOT NULL, facility_id VARCHAR(8) NOT NULL REFERENCES facilities);
CREATE TABLE medical_specialties (specialty_id VARCHAR(8) PRIMARY KEY, specialty TEXT NOT NULL, department_id VARCHAR(8) NOT NULL REFERENCES departments);
CREATE TABLE services (service_id VARCHAR(10) PRIMARY KEY, service_name TEXT NOT NULL, department_id VARCHAR(8) NOT NULL REFERENCES departments);
CREATE TABLE medical_equipment (equipment_id VARCHAR(8) PRIMARY KEY, equipment_name TEXT NOT NULL, department_id VARCHAR(8) NOT NULL REFERENCES departments, facility_id VARCHAR(8) NOT NULL REFERENCES facilities);
CREATE TABLE rooms (room_id VARCHAR(8) PRIMARY KEY, department_id VARCHAR(8) NOT NULL REFERENCES departments, facility_id VARCHAR(8) NOT NULL REFERENCES facilities, room_name TEXT NOT NULL);
CREATE TABLE beds  (bed_id VARCHAR(10) PRIMARY KEY, room_id VARCHAR(8) NOT NULL REFERENCES rooms, status TEXT NOT NULL CHECK (status IN ('Available','Occupied','Maintenance')));

-- ---------- Staff (6 source files unified) ----------
CREATE TABLE staff (
  staff_id VARCHAR(10) PRIMARY KEY, first_name TEXT, last_name TEXT, role TEXT, department TEXT, specialty TEXT,
  facility_id VARCHAR(8) NOT NULL REFERENCES facilities, department_id VARCHAR(8) NOT NULL REFERENCES departments,
  years_experience INT CHECK (years_experience BETWEEN 0 AND 60), status TEXT,
  staff_type TEXT NOT NULL CHECK (staff_type IN ('Doctor','Nurse','Pharmacist','Laboratory Scientist','Radiographer','Administrative')));

-- ---------- Patients ----------
CREATE TABLE patients (
  patient_id VARCHAR(10) PRIMARY KEY, first_name TEXT, last_name TEXT, gender TEXT CHECK (gender IN ('Male','Female')),
  date_of_birth DATE, age INT CHECK (age BETWEEN 0 AND 120), marital_status TEXT, occupation TEXT, education TEXT,
  village_id VARCHAR(8) NOT NULL REFERENCES villages, insurance_id VARCHAR(8), blood_group VARCHAR(4),
  height_cm INT, weight_kg INT, chronic_condition TEXT NOT NULL, phone_raw TEXT, emergency_contact TEXT, status TEXT, bmi NUMERIC(5,1),
  phone_valid BOOLEAN, age_group TEXT);

-- ---------- Appointments & clinical transactions ----------
-- appointment_registry = every AppointmentID that appears in ANY transactional table (60,000).
-- Only 5,000 of them have a full row in appointments (has_details = TRUE).
CREATE TABLE appointment_registry (appointment_id VARCHAR(12) PRIMARY KEY, has_details BOOLEAN NOT NULL);
CREATE TABLE appointments (
  appointment_id VARCHAR(12) PRIMARY KEY REFERENCES appointment_registry,
  patient_id VARCHAR(10) NOT NULL REFERENCES patients, doctor_id VARCHAR(10) NOT NULL REFERENCES staff,
  facility_id VARCHAR(8) NOT NULL REFERENCES facilities, department_id VARCHAR(8) NOT NULL REFERENCES departments,
  appointment_date DATE NOT NULL, visit_type TEXT NOT NULL CHECK (visit_type IN ('Consultation','Follow-up','Emergency')),
  dept_in_facility BOOLEAN, is_future_dated BOOLEAN);
CREATE TABLE diagnoses (diagnosis_id VARCHAR(10) PRIMARY KEY, appointment_id VARCHAR(12) NOT NULL REFERENCES appointment_registry, diagnosis TEXT NOT NULL, severity TEXT CHECK (severity IN ('Mild','Moderate','Severe')));
CREATE TABLE lab_tests (lab_id VARCHAR(10) PRIMARY KEY, appointment_id VARCHAR(12) NOT NULL REFERENCES appointment_registry, test TEXT NOT NULL, result TEXT);
CREATE TABLE prescriptions (prescription_id VARCHAR(10) PRIMARY KEY, appointment_id VARCHAR(12) NOT NULL REFERENCES appointment_registry, medication TEXT NOT NULL, dosage TEXT);
CREATE TABLE admissions (admission_id VARCHAR(10) PRIMARY KEY, appointment_id VARCHAR(12) NOT NULL REFERENCES appointment_registry, length_of_stay_days INT NOT NULL CHECK (length_of_stay_days >= 0));
CREATE TABLE referrals (referral_id VARCHAR(10) PRIMARY KEY, appointment_id VARCHAR(12) NOT NULL REFERENCES appointment_registry, referred_facility_id VARCHAR(8) NOT NULL REFERENCES facilities);

-- ---------- Financial ----------
CREATE TABLE billing (billing_id VARCHAR(12) PRIMARY KEY, appointment_id VARCHAR(12) NOT NULL UNIQUE REFERENCES appointment_registry, amount NUMERIC(14,2) NOT NULL CHECK (amount > 0), status TEXT CHECK (status IN ('Paid','Partially Paid','Pending')));
CREATE TABLE payments (payment_id VARCHAR(12) PRIMARY KEY, billing_id VARCHAR(12) NOT NULL REFERENCES billing, amount_paid NUMERIC(14,2) NOT NULL CHECK (amount_paid >= 0), method TEXT);
CREATE TABLE insurance_claims (claim_id VARCHAR(12) PRIMARY KEY, billing_id VARCHAR(12) NOT NULL REFERENCES billing, provider TEXT NOT NULL, claim_amount NUMERIC(14,2) NOT NULL CHECK (claim_amount >= 0), status TEXT CHECK (status IN ('Approved','Pending','Rejected')));
CREATE TABLE patient_feedback (feedback_id VARCHAR(10) PRIMARY KEY, appointment_id VARCHAR(12) NOT NULL REFERENCES appointment_registry, rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5), comment TEXT, rating_category TEXT);
CREATE TABLE revenue_summary (month DATE PRIMARY KEY, revenue NUMERIC(16,2) NOT NULL, appointments INT NOT NULL);

-- ---------- Indexes on join / filter columns ----------
CREATE INDEX ix_patients_village ON patients(village_id);
CREATE INDEX ix_appt_patient ON appointments(patient_id);
CREATE INDEX ix_appt_doctor ON appointments(doctor_id);
CREATE INDEX ix_appt_fac ON appointments(facility_id);
CREATE INDEX ix_appt_dept ON appointments(department_id);
CREATE INDEX ix_appt_date ON appointments(appointment_date);
CREATE INDEX ix_diag_appt ON diagnoses(appointment_id);
CREATE INDEX ix_lab_appt ON lab_tests(appointment_id);
CREATE INDEX ix_rx_appt ON prescriptions(appointment_id);
CREATE INDEX ix_adm_appt ON admissions(appointment_id);
CREATE INDEX ix_ref_appt ON referrals(appointment_id);
CREATE INDEX ix_pay_bill ON payments(billing_id);
CREATE INDEX ix_claim_bill ON insurance_claims(billing_id);
CREATE INDEX ix_fb_appt ON patient_feedback(appointment_id);
CREATE INDEX ix_staff_fac ON staff(facility_id);

-- ---------- Reporting views ----------
CREATE VIEW v_patient_geo AS
SELECT p.*, v.village_name, s.sector_id, s.sector_name, d.district_id, d.district_name, pr.province_id, pr.province_name
FROM patients p JOIN villages v USING (village_id) JOIN sectors s USING (sector_id) JOIN districts d USING (district_id) JOIN provinces pr USING (province_id);

-- Detailed appointments (the 5,000 with full attributes), enriched with department name, patient province and month
CREATE VIEW v_appointments AS
SELECT a.*, dep.department_name, g.province_name, g.district_name, g.gender, g.age, g.age_group,
       date_trunc('month', a.appointment_date)::date AS appt_month, to_char(a.appointment_date,'Dy') AS appt_dow
FROM appointments a JOIN departments dep USING (department_id) JOIN v_patient_geo g USING (patient_id);

-- One row per bill with amount paid, outstanding balance and claim details
CREATE VIEW v_billing AS
SELECT b.billing_id, b.appointment_id, b.amount, b.status AS bill_status,
       COALESCE(SUM(py.amount_paid),0) AS amount_paid, b.amount - COALESCE(SUM(py.amount_paid),0) AS outstanding,
       MAX(py.method) AS payment_method, MAX(c.provider) AS provider, MAX(c.claim_amount) AS claim_amount, MAX(c.status) AS claim_status
FROM billing b LEFT JOIN payments py USING (billing_id) LEFT JOIN insurance_claims c USING (billing_id)
GROUP BY b.billing_id, b.appointment_id, b.amount, b.status;
