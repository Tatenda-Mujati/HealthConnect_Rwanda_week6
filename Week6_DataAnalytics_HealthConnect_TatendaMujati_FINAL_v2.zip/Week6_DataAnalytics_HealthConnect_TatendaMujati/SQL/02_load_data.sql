-- 02_load_data.sql | run from the SQL/ folder:  psql -d healthconnect -f 02_load_data.sql
-- Loads the cleaned CSVs in ../Data/Cleaned (client-side \copy, so relative paths work).
SET search_path = hc, public;
\copy countries FROM '../Data/Cleaned/countries.csv' CSV HEADER
\copy provinces FROM '../Data/Cleaned/provinces.csv' CSV HEADER
\copy districts FROM '../Data/Cleaned/districts.csv' CSV HEADER
\copy sectors FROM '../Data/Cleaned/sectors.csv' CSV HEADER
\copy villages FROM '../Data/Cleaned/villages.csv' CSV HEADER
\copy ownership_types FROM '../Data/Cleaned/ownership_types.csv' CSV HEADER
\copy facilities FROM '../Data/Cleaned/facilities.csv' CSV HEADER
\copy departments FROM '../Data/Cleaned/departments.csv' CSV HEADER
\copy medical_specialties FROM '../Data/Cleaned/medical_specialties.csv' CSV HEADER
\copy services FROM '../Data/Cleaned/services.csv' CSV HEADER
\copy medical_equipment FROM '../Data/Cleaned/medical_equipment.csv' CSV HEADER
\copy rooms FROM '../Data/Cleaned/rooms.csv' CSV HEADER
\copy beds FROM '../Data/Cleaned/beds.csv' CSV HEADER
\copy staff FROM '../Data/Cleaned/staff.csv' CSV HEADER
\copy patients FROM '../Data/Cleaned/patients.csv' CSV HEADER
\copy appointment_registry FROM '../Data/Cleaned/appointment_registry.csv' CSV HEADER
\copy appointments FROM '../Data/Cleaned/appointments.csv' CSV HEADER
\copy diagnoses FROM '../Data/Cleaned/diagnoses.csv' CSV HEADER
\copy lab_tests FROM '../Data/Cleaned/lab_tests.csv' CSV HEADER
\copy prescriptions FROM '../Data/Cleaned/prescriptions.csv' CSV HEADER
\copy admissions FROM '../Data/Cleaned/admissions.csv' CSV HEADER
\copy referrals FROM '../Data/Cleaned/referrals.csv' CSV HEADER
\copy billing FROM '../Data/Cleaned/billing.csv' CSV HEADER
\copy payments FROM '../Data/Cleaned/payments.csv' CSV HEADER
\copy insurance_claims FROM '../Data/Cleaned/insurance_claims.csv' CSV HEADER
\copy patient_feedback FROM '../Data/Cleaned/patient_feedback.csv' CSV HEADER
\copy revenue_summary FROM '../Data/Cleaned/revenue_summary.csv' CSV HEADER
ANALYZE;
SELECT 'row counts loaded' AS info;
SELECT table_name, (xpath('/row/c/text()', query_to_xml(format('select count(*) as c from hc.%I', table_name), false, true, '')))[1]::text::int AS row_count
FROM information_schema.tables WHERE table_schema='hc' AND table_type='BASE TABLE' ORDER BY 1;
