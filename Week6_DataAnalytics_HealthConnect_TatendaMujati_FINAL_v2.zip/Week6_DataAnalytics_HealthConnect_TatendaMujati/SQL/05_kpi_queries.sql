-- =====================================================================
-- 05_kpi_queries.sql - one query per KPI required in the brief (feeds the Power BI dashboard)
-- Definitions are documented in PowerBI/KPI_Definitions.md
-- =====================================================================
SET search_path = hc, public;
-- ---------------- PATIENT KPIs ----------------
-- K01 | Total registered patients
SELECT COUNT(*) AS total_registered_patients FROM patients;
-- K02 | Active patients (status = Active)
SELECT COUNT(*) FILTER (WHERE status='Active') AS active_patients, COUNT(*) FILTER (WHERE status='Active' AND patient_id IN (SELECT patient_id FROM appointments)) AS active_with_visit FROM patients;
-- K03 | New vs returning patients (visit-based: 1 detailed appointment = new, 2+ = returning)
SELECT CASE WHEN visits = 1 THEN 'New (1 visit)' ELSE 'Returning (2+ visits)' END AS patient_type, COUNT(*) AS patients FROM (SELECT patient_id, COUNT(*) AS visits FROM appointments GROUP BY patient_id) x GROUP BY 1 ORDER BY 1;
-- K04 | Male vs female patients
SELECT gender, COUNT(*) AS patients, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct FROM patients GROUP BY gender;
-- K05 | Age group distribution (age pyramid data: gender x age group)
SELECT age_group, gender, COUNT(*) AS patients FROM patients GROUP BY age_group, gender ORDER BY age_group, gender;
-- K06 | Blood group distribution
SELECT blood_group, COUNT(*) AS patients FROM patients GROUP BY blood_group ORDER BY patients DESC;
-- K07 | Insurance coverage rate (patients holding an InsuranceID; plus share of bills with an insurance claim)
SELECT ROUND(100.0*COUNT(*) FILTER (WHERE insurance_id IS NOT NULL AND insurance_id<>'')/COUNT(*),2) AS patients_with_insurance_id_pct,
       (SELECT ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM billing),2) FROM insurance_claims) AS bills_with_claim_pct FROM patients;
-- K08 | Patients by province
SELECT province_name, COUNT(*) AS patients FROM v_patient_geo GROUP BY province_name ORDER BY patients DESC;
-- K09 | Patients by district (top 10)
SELECT province_name, district_name, COUNT(*) AS patients FROM v_patient_geo GROUP BY province_name, district_name ORDER BY patients DESC LIMIT 10;
-- K10 | Patients by chronic disease
SELECT chronic_condition, COUNT(*) AS patients, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct FROM patients GROUP BY chronic_condition ORDER BY patients DESC;
-- K11 | Average patient age
SELECT ROUND(AVG(age),2) AS avg_age FROM patients;
-- ---------------- APPOINTMENT KPIs ----------------
-- K12 | Total appointments (all IDs vs detailed)
SELECT COUNT(*) AS appointment_ids_all, COUNT(*) FILTER (WHERE has_details) AS appointments_with_details FROM appointment_registry;
-- K13 | Daily appointments (detailed; average per calendar day with activity)
SELECT ROUND(AVG(n),2) AS avg_daily_appointments, MAX(n) AS busiest_day_count FROM (SELECT appointment_date, COUNT(*) AS n FROM appointments GROUP BY 1) d;
-- K14 | Monthly appointments + growth rate (Revenue_Summary appointment counts, all 60,809)
SELECT to_char(month,'YYYY-MM') AS month, appointments, ROUND(100.0*(appointments-LAG(appointments) OVER (ORDER BY month))/LAG(appointments) OVER (ORDER BY month),2) AS mom_growth_pct FROM revenue_summary ORDER BY month;
-- K15 | Emergency / follow-up / consultation appointments
SELECT visit_type, COUNT(*) AS appointments FROM appointments GROUP BY visit_type;
-- K16 | Referral rate (all referrals / all appointment IDs)
SELECT COUNT(*) AS referrals, ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM appointment_registry),2) AS referral_rate_pct FROM referrals;
-- K17 | Appointment cancellation rate - NOT AVAILABLE (no status field in source data)
SELECT 'n/a - appointment status (cancelled / no-show) not recorded in the source data' AS note;
-- K18 | Average appointments per doctor (detailed)
SELECT ROUND(COUNT(*)::numeric/(SELECT COUNT(*) FROM staff WHERE staff_type='Doctor'),2) AS avg_appointments_per_doctor FROM appointments;
-- ---------------- CLINICAL KPIs ----------------
-- K19 | Top 20 diagnoses (only 5 distinct diagnoses exist)
SELECT diagnosis, COUNT(*) AS cases FROM diagnoses GROUP BY diagnosis ORDER BY cases DESC LIMIT 20;
-- K20 | Disease severity distribution
SELECT severity, COUNT(*) AS cases, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct FROM diagnoses GROUP BY severity ORDER BY severity;
-- K21 | Laboratory test volume / prescription volume
SELECT (SELECT COUNT(*) FROM lab_tests) AS lab_tests, (SELECT COUNT(*) FROM prescriptions) AS prescriptions;
-- K22 | Admission rate (admissions / all appointment IDs) and detailed-only rate
SELECT ROUND(100.0*(SELECT COUNT(*) FROM admissions)/(SELECT COUNT(*) FROM appointment_registry),2) AS admission_rate_pct_all,
       ROUND(100.0*(SELECT COUNT(*) FROM admissions ad JOIN appointments USING (appointment_id))/(SELECT COUNT(*) FROM appointments),2) AS admission_rate_pct_detailed;
-- K23 | Average length of stay
SELECT ROUND(AVG(length_of_stay_days),2) AS avg_length_of_stay_days FROM admissions;
-- K24 | Referral distribution (destination facility)
SELECT referred_facility_id, COUNT(*) AS referrals FROM referrals GROUP BY 1 ORDER BY 2 DESC;
-- K25 | Readmission indicator: patients with 2+ admissions (admissions linked to a patient via detailed appointments)
SELECT COUNT(*) FILTER (WHERE adm >= 2) AS patients_readmitted, COUNT(*) AS patients_admitted, ROUND(100.0*COUNT(*) FILTER (WHERE adm >= 2)/NULLIF(COUNT(*),0),2) AS readmission_pct
FROM (SELECT a.patient_id, COUNT(*) AS adm FROM admissions ad JOIN appointments a USING (appointment_id) GROUP BY a.patient_id) x;
-- K26 | Most common medications
SELECT medication, COUNT(*) AS prescriptions FROM prescriptions GROUP BY 1 ORDER BY 2 DESC;
-- ---------------- HEALTHCARE STAFF KPIs ----------------
-- K27 | Staff headcount by type (doctors, nurses, pharmacists, lab scientists, radiographers, admin)
SELECT staff_type, COUNT(*) AS staff FROM staff GROUP BY staff_type ORDER BY staff DESC;
-- K28 | Staff distribution by facility
SELECT facility_id, COUNT(*) AS staff, COUNT(*) FILTER (WHERE staff_type='Doctor') AS doctors, COUNT(*) FILTER (WHERE staff_type='Nurse') AS nurses FROM staff GROUP BY 1 ORDER BY 1;
-- K29 | Staff distribution by department (department name)
SELECT department, staff_type, COUNT(*) AS staff FROM staff GROUP BY 1,2 ORDER BY 1,2;
-- K30 | Average years of experience (by staff type)
SELECT staff_type, ROUND(AVG(years_experience),2) AS avg_years FROM staff GROUP BY 1 UNION ALL SELECT 'All staff', ROUND(AVG(years_experience),2) FROM staff;
-- K31 | Staff-to-patient ratio (registered patients per staff member; per clinician)
SELECT ROUND((SELECT COUNT(*) FROM patients)::numeric/COUNT(*),2) AS patients_per_staff,
       ROUND((SELECT COUNT(*) FROM patients)::numeric/COUNT(*) FILTER (WHERE staff_type IN ('Doctor','Nurse')),2) AS patients_per_doctor_or_nurse,
       ROUND((SELECT COUNT(*) FROM patients)::numeric/COUNT(*) FILTER (WHERE staff_type='Doctor'),2) AS patients_per_doctor FROM staff;
-- ---------------- OPERATIONAL KPIs ----------------
-- K32 | Number of health facilities / facility type distribution (type not supplied)
SELECT COUNT(*) AS health_facilities FROM facilities;
-- K33 | Bed capacity and available beds by facility
SELECT r.facility_id, COUNT(*) AS bed_capacity, COUNT(*) FILTER (WHERE b.status='Available') AS available_beds FROM beds b JOIN rooms r USING (room_id) GROUP BY 1 ORDER BY 1;
-- K34 | Bed utilisation: recorded status vs modelled (admission bed-days / (beds x 365))
SELECT ROUND(100.0*COUNT(*) FILTER (WHERE status='Occupied')/COUNT(*),2) AS recorded_occupancy_pct,
       ROUND(100.0*(SELECT SUM(length_of_stay_days) FROM admissions)/(COUNT(*)*365.0),2) AS modelled_utilisation_pct FROM beds;
-- K35 | Room utilisation proxy: beds per room and rooms per facility
SELECT r.facility_id, COUNT(DISTINCT r.room_id) AS rooms, COUNT(b.bed_id) AS beds, ROUND(COUNT(b.bed_id)::numeric/COUNT(DISTINCT r.room_id),2) AS beds_per_room FROM rooms r LEFT JOIN beds b USING (room_id) GROUP BY 1 ORDER BY 1;
-- K36 | Equipment distribution (units by facility)
SELECT facility_id, COUNT(*) AS equipment_units FROM medical_equipment GROUP BY 1 ORDER BY 1;
-- K37 | Department capacity (rooms, beds, equipment, staff per department name)
SELECT d.department_name, COUNT(DISTINCT d.department_id) AS departments, COUNT(DISTINCT r.room_id) AS rooms, COUNT(DISTINCT b.bed_id) AS beds, COUNT(DISTINCT e.equipment_id) AS equipment
FROM departments d LEFT JOIN rooms r USING (department_id) LEFT JOIN beds b USING (room_id) LEFT JOIN medical_equipment e ON e.department_id = d.department_id GROUP BY 1 ORDER BY 1;
-- K38 | Facility performance ranking (composite: appointments, billed revenue, avg rating - detailed appointments)
WITH f AS (SELECT a.facility_id, COUNT(*) AS appts, SUM(b.amount) AS billed, AVG(fb.rating) AS avg_rating
  FROM appointments a JOIN billing b USING (appointment_id) LEFT JOIN patient_feedback fb USING (appointment_id) GROUP BY 1),
r AS (SELECT facility_id, appts, billed, avg_rating,
       RANK() OVER (ORDER BY appts DESC) + RANK() OVER (ORDER BY billed DESC) + RANK() OVER (ORDER BY avg_rating DESC) AS rank_sum FROM f)
SELECT facility_id, appts, billed, ROUND(avg_rating,2) AS avg_rating, rank_sum, RANK() OVER (ORDER BY rank_sum) AS overall_rank FROM r ORDER BY rank_sum, facility_id;
-- ---------------- FINANCIAL KPIs ----------------
-- K39 | Total revenue (billed), collected, outstanding
SELECT SUM(amount) AS total_billed_rwf, SUM(amount_paid) AS collected_rwf, SUM(outstanding) AS outstanding_rwf, ROUND(100.0*SUM(amount_paid)/SUM(amount),2) AS collection_rate_pct FROM v_billing;
-- K40 | Revenue by province (patient residence; detailed appointments)
SELECT a.province_name, SUM(b.amount) AS billed_rwf, COUNT(*) AS bills FROM v_appointments a JOIN billing b USING (appointment_id) GROUP BY 1 ORDER BY 2 DESC;
-- K41 | Insurance claim approval rate
SELECT ROUND(100.0*COUNT(*) FILTER (WHERE status='Approved')/COUNT(*),2) AS approval_rate_pct, COUNT(*) AS claims FROM insurance_claims;
-- K42 | Average billing amount
SELECT ROUND(AVG(amount),0) AS avg_bill_rwf FROM billing;
-- K43 | Revenue growth rate (Revenue_Summary: Jan-Oct actual vs prior month; full-year first-half vs second-half)
SELECT ROUND(100.0*(SUM(revenue) FILTER (WHERE month >= '2026-07-01') - SUM(revenue) FILTER (WHERE month < '2026-07-01'))/SUM(revenue) FILTER (WHERE month < '2026-07-01'),2) AS h2_vs_h1_growth_pct FROM revenue_summary;
-- ---------------- PATIENT EXPERIENCE KPIs ----------------
-- K44 | Average satisfaction rating and rating distribution
SELECT rating, COUNT(*) AS responses, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct, (SELECT ROUND(AVG(rating),3) FROM patient_feedback) AS avg_rating FROM patient_feedback GROUP BY rating ORDER BY rating;
-- K45 | Satisfaction by hospital (detailed appointments with feedback)
SELECT a.facility_id, COUNT(*) AS responses, ROUND(AVG(f.rating),2) AS avg_rating FROM patient_feedback f JOIN appointments a USING (appointment_id) GROUP BY 1 ORDER BY avg_rating DESC;
-- K46 | Satisfaction by department
SELECT a.department_name, COUNT(*) AS responses, ROUND(AVG(f.rating),2) AS avg_rating FROM patient_feedback f JOIN v_appointments a USING (appointment_id) GROUP BY 1 ORDER BY avg_rating DESC;
-- K47 | Most common feedback comments
SELECT comment, COUNT(*) AS responses FROM patient_feedback GROUP BY 1 ORDER BY 2 DESC;
-- K48 | Poor (1-2) and excellent (5) rating trend by month (detailed appointments with feedback)
SELECT to_char(a.appt_month,'YYYY-MM') AS month, COUNT(*) AS responses, COUNT(*) FILTER (WHERE f.rating <= 2) AS poor_ratings, COUNT(*) FILTER (WHERE f.rating = 5) AS excellent_ratings,
       ROUND(100.0*COUNT(*) FILTER (WHERE f.rating <= 2)/COUNT(*),2) AS poor_pct, ROUND(100.0*COUNT(*) FILTER (WHERE f.rating = 5)/COUNT(*),2) AS excellent_pct
FROM patient_feedback f JOIN v_appointments a USING (appointment_id) GROUP BY a.appt_month ORDER BY a.appt_month;
-- K49 | Complaint trend (poor-rated feedback, rating 1-2) by month - all feedback joined to detailed appointments
SELECT to_char(a.appt_month,'YYYY-MM') AS month, COUNT(*) FILTER (WHERE f.rating <= 2) AS complaints FROM patient_feedback f JOIN v_appointments a USING (appointment_id) GROUP BY a.appt_month ORDER BY a.appt_month;
