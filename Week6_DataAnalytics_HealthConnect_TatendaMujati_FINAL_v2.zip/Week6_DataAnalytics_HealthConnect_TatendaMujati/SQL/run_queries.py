import re,subprocess,sys,csv,io,os
f=sys.argv[1]; out=sys.argv[2]; os.makedirs(out,exist_ok=True)
txt=open(f).read()
parts=re.split(r'^-- ([QK]\d+[a-z]?) \| (.*)$',txt,flags=re.M)
hdr=parts[0]
n=0
for i in range(1,len(parts),3):
    qid,title,body=parts[i],parts[i+1],parts[i+2]
    sql=re.sub(r'^-- =+.*$|^-- [A-Z =]+$','',body,flags=re.M).strip()
    r=subprocess.run(['psql','-h','/tmp','-p','5433','-U','postgres','-d','healthconnect','-v','ON_ERROR_STOP=1','--csv','-c','SET search_path=hc,public',  '-c',sql],capture_output=True,text=True)
    if r.returncode: print('FAIL',qid,r.stderr[:400]); continue
    rows=list(csv.reader(io.StringIO(r.stdout.split('\n',0)[0])))
    # psql prints SET result? with --csv and multiple -c only last result is printed per command: filter
    lines=r.stdout.strip().split('\n')
    while lines and lines[0]=='SET': lines=lines.pop(0) and lines
    rows=list(csv.reader(lines))
    total=len(rows)-1
    with open(f'{out}/{qid}.csv','w',newline='') as fh: csv.writer(fh).writerows(rows[:101])
    print(qid,total,'rows',title[:60]); n+=1
print(n,'queries ok')
