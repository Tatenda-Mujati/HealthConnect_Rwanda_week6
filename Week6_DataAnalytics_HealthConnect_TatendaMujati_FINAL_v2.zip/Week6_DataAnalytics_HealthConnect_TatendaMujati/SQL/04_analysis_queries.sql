-- =====================================================================
-- 04_analysis_queries.sql  -  the 40 required business questions (PostgreSQL 16)
-- Run:  psql -d healthconnect -f 04_analysis_queries.sql
-- Each query starts with a marker line "-- Qnn | title".
--
-- READ FIRST - data scope notes (see Data Quality Report):
--  * "Universe" = the 60,000 AppointmentIDs found in Billing/Diagnoses (appointment_registry).
--  * Only 5,000 appointments have facility / department / doctor / date (appointments table).
--    Any query by facility, department, doctor, month, visit type or province therefore uses
--    those 5,000 "detailed" appointments and says so in its column names / notes.
--  * Department analysis groups by department NAME (service line) because 95% of appointment
--    DepartmentIDs do not belong to the appointment's FacilityID.
--  * Province = province of the PATIENT's village (no Health Facilities master was supplied).
-- =====================================================================
SET search_path = hc, public;

-- ============================ PATIENT ANALYSIS ============================
-- Q01 | Retrieve all registered patients
SELECT patient_id, first_name, last_name, gender, date_of_birth, age, age_group, blood_group, chronic_condition,
       insurance_id, province_name, district_name, sector_name, village_name, status
FROM v_patient_geo ORDER BY patient_id;

-- Q02 | Count patients by gender
SELECT gender, COUNT(*) AS patients, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct
FROM patients GROUP BY gender ORDER BY patients DESC;

-- Q03 | Count patients by province (province of residence)
SELECT province_name, COUNT(*) AS patients, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct
FROM v_patient_geo GROUP BY province_name ORDER BY patients DESC;

-- Q04 | Identify patients above 65 years
SELECT patient_id, first_name, last_name, gender, age, chronic_condition, province_name
FROM v_patient_geo WHERE age > 65 ORDER BY age DESC, patient_id;

-- Q05 | Find patients with chronic diseases
SELECT patient_id, first_name, last_name, gender, age, chronic_condition, province_name
FROM v_patient_geo WHERE chronic_condition <> 'None' ORDER BY chronic_condition, patient_id;

-- Q06 | Retrieve patients covered by insurance (every patient carries an InsuranceID - no uninsured flag exists)
SELECT patient_id, first_name, last_name, insurance_id, province_name
FROM v_patient_geo WHERE insurance_id IS NOT NULL AND insurance_id <> '' ORDER BY insurance_id, patient_id;

-- Q07 | Count patients by blood group
SELECT blood_group, COUNT(*) AS patients, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct
FROM patients GROUP BY blood_group ORDER BY patients DESC;

-- Q08 | List the youngest and oldest patients (ties included: many patients share the min / max age)
WITH r AS (SELECT MIN(age) AS youngest, MAX(age) AS oldest FROM patients)
SELECT CASE WHEN p.age = r.youngest THEN 'Youngest' ELSE 'Oldest' END AS category,
       p.patient_id, p.first_name, p.last_name, p.gender, p.age, p.date_of_birth
FROM patients p, r WHERE p.age IN (r.youngest, r.oldest) ORDER BY category DESC, p.patient_id;

-- Q09 | Identify duplicate phone numbers (phone_raw was corrupted to scientific notation - see DQ report)
SELECT phone_raw, phone_valid, COUNT(*) AS patients_sharing_value
FROM patients GROUP BY phone_raw, phone_valid HAVING COUNT(*) > 1 ORDER BY patients_sharing_value DESC;

-- Q10 | Calculate average patient age
SELECT 'All patients' AS segment, ROUND(AVG(age),2) AS avg_age, COUNT(*) AS patients FROM patients
UNION ALL SELECT gender, ROUND(AVG(age),2), COUNT(*) FROM patients GROUP BY gender ORDER BY 1;

-- ============================ APPOINTMENT ANALYSIS ============================
-- Q11 | Count appointments by month (5,000 detailed appointments)
SELECT appt_month AS month, COUNT(*) AS appointments, COUNT(*) FILTER (WHERE is_future_dated) AS dated_after_22oct2026
FROM v_appointments GROUP BY appt_month ORDER BY appt_month;

-- Q12 | Identify busiest hospitals (facilities)
SELECT facility_id, COUNT(*) AS appointments, RANK() OVER (ORDER BY COUNT(*) DESC) AS busy_rank
FROM appointments GROUP BY facility_id ORDER BY appointments DESC, facility_id;

-- Q13 | Find busiest departments (by department name / service line)
SELECT department_name, COUNT(*) AS appointments, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct,
       RANK() OVER (ORDER BY COUNT(*) DESC) AS busy_rank
FROM v_appointments GROUP BY department_name ORDER BY appointments DESC;

-- Q14 | Find doctors with the highest workload (top 20)
SELECT s.staff_id AS doctor_id, s.first_name || ' ' || s.last_name AS doctor, s.specialty, s.facility_id AS home_facility,
       COUNT(*) AS appointments, COUNT(DISTINCT a.patient_id) AS distinct_patients
FROM appointments a JOIN staff s ON s.staff_id = a.doctor_id
GROUP BY s.staff_id, s.first_name, s.last_name, s.specialty, s.facility_id
ORDER BY appointments DESC, doctor_id LIMIT 20;

-- Q15 | Identify referral patterns: top origin -> destination flows (referrals whose appointment has details)
SELECT a.facility_id AS from_facility, r.referred_facility_id AS to_facility, COUNT(*) AS referrals
FROM referrals r JOIN appointments a USING (appointment_id)
GROUP BY a.facility_id, r.referred_facility_id ORDER BY referrals DESC, from_facility, to_facility LIMIT 20;

-- Q16 | Count emergency appointments
SELECT visit_type, COUNT(*) AS appointments, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct
FROM appointments GROUP BY visit_type ORDER BY appointments DESC;

-- Q17 | Calculate average appointments per doctor
SELECT COUNT(*) AS detailed_appointments,
       (SELECT COUNT(*) FROM staff WHERE staff_type='Doctor') AS doctors_on_roster,
       COUNT(DISTINCT doctor_id) AS doctors_with_appointments,
       ROUND(COUNT(*)::numeric / (SELECT COUNT(*) FROM staff WHERE staff_type='Doctor'),2) AS avg_appointments_per_doctor
FROM appointments;

-- Q18 | Retrieve appointments by province (patient residence)
SELECT province_name, COUNT(*) AS appointments, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct
FROM v_appointments GROUP BY province_name ORDER BY appointments DESC;

-- Q19 | Identify facilities with the highest patient volume (distinct patients)
SELECT facility_id, COUNT(DISTINCT patient_id) AS distinct_patients, COUNT(*) AS appointments,
       RANK() OVER (ORDER BY COUNT(DISTINCT patient_id) DESC) AS volume_rank
FROM appointments GROUP BY facility_id ORDER BY distinct_patients DESC, facility_id;

-- Q20 | Find peak consultation periods (Consultation visits by month and weekday)
SELECT 'Month' AS period_type, to_char(appt_month,'YYYY-MM') AS period, COUNT(*) AS consultations,
       RANK() OVER (ORDER BY COUNT(*) DESC) AS peak_rank
FROM v_appointments WHERE visit_type='Consultation' GROUP BY appt_month
UNION ALL
SELECT 'Weekday', appt_dow, COUNT(*), RANK() OVER (ORDER BY COUNT(*) DESC)
FROM v_appointments WHERE visit_type='Consultation' GROUP BY appt_dow
ORDER BY period_type, peak_rank;

-- ============================ CLINICAL ANALYSIS ============================
-- Q21 | Top diagnoses (all 60,000 diagnosis records)
SELECT diagnosis, COUNT(*) AS cases, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct,
       RANK() OVER (ORDER BY COUNT(*) DESC) AS rank
FROM diagnoses GROUP BY diagnosis ORDER BY cases DESC;

-- Q22 | Most requested laboratory tests
SELECT test, COUNT(*) AS requests, COUNT(*) FILTER (WHERE result='Abnormal') AS abnormal,
       ROUND(100.0*COUNT(*) FILTER (WHERE result='Abnormal')/COUNT(*),2) AS abnormal_pct
FROM lab_tests GROUP BY test ORDER BY requests DESC;

-- Q23 | Most prescribed medications
SELECT medication, COUNT(*) AS prescriptions, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct
FROM prescriptions GROUP BY medication ORDER BY prescriptions DESC;

-- Q24 | Average admission duration (days)
SELECT COUNT(*) AS admissions, ROUND(AVG(length_of_stay_days),2) AS avg_los_days,
       PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY length_of_stay_days) AS median_los_days,
       MIN(length_of_stay_days) AS min_los, MAX(length_of_stay_days) AS max_los, SUM(length_of_stay_days) AS total_bed_days
FROM admissions;

-- Q25 | Disease severity distribution (overall and by diagnosis)
SELECT diagnosis, severity, COUNT(*) AS cases,
       ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (PARTITION BY diagnosis),2) AS pct_within_diagnosis
FROM diagnoses GROUP BY diagnosis, severity ORDER BY diagnosis, severity;

-- Q26 | Laboratory test utilisation by department (detailed appointments)
SELECT a.department_name, COUNT(DISTINCT a.appointment_id) AS appointments, COUNT(l.lab_id) AS lab_tests,
       ROUND(100.0*COUNT(l.lab_id)/COUNT(DISTINCT a.appointment_id),2) AS lab_tests_per_100_appointments
FROM v_appointments a LEFT JOIN lab_tests l USING (appointment_id)
GROUP BY a.department_name ORDER BY lab_tests DESC;

-- Q27 | Prescription trends: monthly prescriptions by medication (detailed appointments)
SELECT to_char(a.appt_month,'YYYY-MM') AS month, p.medication, COUNT(*) AS prescriptions
FROM prescriptions p JOIN v_appointments a USING (appointment_id)
GROUP BY a.appt_month, p.medication ORDER BY month, prescriptions DESC;

-- Q28 | Referral destinations (all 4,708 referrals)
SELECT referred_facility_id, COUNT(*) AS referrals_received, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct,
       RANK() OVER (ORDER BY COUNT(*) DESC) AS rank
FROM referrals GROUP BY referred_facility_id ORDER BY referrals_received DESC, referred_facility_id;

-- Q29 | Admission rate by diagnosis (admitted appointments / diagnosed appointments, all 60,000)
SELECT d.diagnosis, COUNT(*) AS diagnosed, COUNT(ad.admission_id) AS admitted,
       ROUND(100.0*COUNT(ad.admission_id)/COUNT(*),2) AS admission_rate_pct
FROM diagnoses d LEFT JOIN admissions ad USING (appointment_id)
GROUP BY d.diagnosis ORDER BY admission_rate_pct DESC;

-- Q30 | Clinical workload by department (detailed appointments)
SELECT a.department_name, COUNT(DISTINCT a.appointment_id) AS appointments,
       (SELECT COUNT(*) FROM diagnoses x   JOIN v_appointments y USING (appointment_id) WHERE y.department_name = a.department_name) AS diagnoses,
       (SELECT COUNT(*) FROM lab_tests x   JOIN v_appointments y USING (appointment_id) WHERE y.department_name = a.department_name) AS lab_tests,
       (SELECT COUNT(*) FROM prescriptions x JOIN v_appointments y USING (appointment_id) WHERE y.department_name = a.department_name) AS prescriptions,
       (SELECT COUNT(*) FROM admissions x  JOIN v_appointments y USING (appointment_id) WHERE y.department_name = a.department_name) AS admissions,
       (SELECT COUNT(*) FROM referrals x   JOIN v_appointments y USING (appointment_id) WHERE y.department_name = a.department_name) AS referrals
FROM v_appointments a GROUP BY a.department_name ORDER BY appointments DESC;

-- ============================ FINANCIAL ANALYSIS ============================
-- Q31 | Revenue by facility (billed amount; detailed appointments only = 5,000 of 60,000 bills)
SELECT a.facility_id, COUNT(*) AS bills, SUM(b.amount) AS billed_rwf, SUM(v.amount_paid) AS collected_rwf,
       ROUND(100.0*SUM(b.amount)/SUM(SUM(b.amount)) OVER (),2) AS share_pct, RANK() OVER (ORDER BY SUM(b.amount) DESC) AS rank
FROM appointments a JOIN billing b USING (appointment_id) JOIN v_billing v USING (billing_id)
GROUP BY a.facility_id ORDER BY billed_rwf DESC;

-- Q32 | Revenue by department (by department name; detailed appointments)
SELECT a.department_name, COUNT(*) AS bills, SUM(b.amount) AS billed_rwf, SUM(v.amount_paid) AS collected_rwf,
       ROUND(100.0*SUM(b.amount)/SUM(SUM(b.amount)) OVER (),2) AS share_pct
FROM v_appointments a JOIN billing b USING (appointment_id) JOIN v_billing v USING (billing_id)
GROUP BY a.department_name ORDER BY billed_rwf DESC;

-- Q33 | Revenue by service (billing is not linked to ServiceID, so service line = visit type)
SELECT a.visit_type AS service_line, COUNT(*) AS bills, SUM(b.amount) AS billed_rwf, ROUND(AVG(b.amount),0) AS avg_bill_rwf,
       ROUND(100.0*SUM(b.amount)/SUM(SUM(b.amount)) OVER (),2) AS share_pct
FROM appointments a JOIN billing b USING (appointment_id) GROUP BY a.visit_type ORDER BY billed_rwf DESC;

-- Q34 | Insurance claims by provider (all 42,036 claims)
SELECT provider, COUNT(*) AS claims, SUM(claim_amount) AS claimed_rwf,
       COUNT(*) FILTER (WHERE status='Approved') AS approved, ROUND(100.0*COUNT(*) FILTER (WHERE status='Approved')/COUNT(*),2) AS approval_rate_pct,
       SUM(claim_amount) FILTER (WHERE status='Approved') AS approved_rwf
FROM insurance_claims GROUP BY provider ORDER BY claimed_rwf DESC;

-- Q35 | Outstanding payments (bill amount - amount paid; Billing.Status is unreliable, see DQ report)
SELECT bill_status, COUNT(*) AS bills, SUM(amount) AS billed_rwf, SUM(amount_paid) AS paid_rwf, SUM(outstanding) AS outstanding_rwf,
       COUNT(*) FILTER (WHERE outstanding > 0) AS bills_with_balance
FROM v_billing GROUP BY ROLLUP (bill_status) ORDER BY bill_status NULLS LAST;

-- Q36 | Average billing amount (overall and by bill status)
SELECT 'All bills' AS segment, COUNT(*) AS bills, ROUND(AVG(amount),0) AS avg_bill_rwf FROM billing
UNION ALL SELECT status, COUNT(*), ROUND(AVG(amount),0) FROM billing GROUP BY status ORDER BY 1;

-- Q37 | Monthly revenue trend: official Revenue_Summary with month-on-month growth, beside linked billing
SELECT to_char(r.month,'YYYY-MM') AS month, r.revenue AS summary_revenue_rwf, r.appointments AS summary_appointments,
       ROUND(100.0*(r.revenue - LAG(r.revenue) OVER (ORDER BY r.month))/LAG(r.revenue) OVER (ORDER BY r.month),2) AS mom_growth_pct,
       lb.billed_rwf AS billed_rwf_detailed_appts
FROM revenue_summary r
LEFT JOIN (SELECT a.appt_month AS m, SUM(b.amount) AS billed_rwf FROM v_appointments a JOIN billing b USING (appointment_id) GROUP BY a.appt_month) lb ON lb.m = r.month
ORDER BY r.month;

-- Q38 | Payment methods
SELECT method, COUNT(*) AS payments, SUM(amount_paid) AS collected_rwf, ROUND(100.0*COUNT(*)/SUM(COUNT(*)) OVER (),2) AS pct_of_payments,
       ROUND(100.0*SUM(amount_paid)/SUM(SUM(amount_paid)) OVER (),2) AS pct_of_value
FROM payments GROUP BY method ORDER BY collected_rwf DESC;

-- Q39 | Top revenue-generating hospitals (top 10 facilities by billed amount)
SELECT a.facility_id, SUM(b.amount) AS billed_rwf, COUNT(*) AS bills, ROUND(AVG(b.amount),0) AS avg_bill_rwf
FROM appointments a JOIN billing b USING (appointment_id) GROUP BY a.facility_id ORDER BY billed_rwf DESC LIMIT 10;

-- Q40 | Financial performance ranking of facilities (billed, collection rate, claim approval rate)
WITH f AS (
  SELECT a.facility_id, SUM(v.amount) AS billed, SUM(v.amount_paid) AS collected,
         COUNT(v.claim_status) AS claims, COUNT(*) FILTER (WHERE v.claim_status='Approved') AS approved
  FROM appointments a JOIN v_billing v USING (appointment_id) GROUP BY a.facility_id)
SELECT facility_id, billed AS billed_rwf, collected AS collected_rwf, ROUND(100.0*collected/billed,2) AS collection_rate_pct,
       ROUND(100.0*approved/NULLIF(claims,0),2) AS claim_approval_pct,
       RANK() OVER (ORDER BY billed DESC) AS revenue_rank, RANK() OVER (ORDER BY collected/billed DESC) AS collection_rank,
       RANK() OVER (ORDER BY billed DESC) + RANK() OVER (ORDER BY collected/billed DESC) AS rank_sum
FROM f ORDER BY rank_sum, facility_id;
