-- =====================================================================
-- 03_validation_checks.sql - post-load data validation (PostgreSQL)
-- Every check returns the number of failing rows (0 = pass) except where marked INFO.
-- Because the schema enforces foreign keys, orphan keys cannot exist inside hc.* - the cleaning step
-- (Python) routes the 55,000 appointment IDs that have no Appointments row into appointment_registry.
-- =====================================================================
SET search_path = hc, public;
SELECT check_name, failing_rows, CASE WHEN failing_rows = 0 THEN 'PASS' ELSE 'REVIEW' END AS result FROM (
  SELECT 'Duplicate PatientID' AS check_name, COUNT(*) - COUNT(DISTINCT patient_id) AS failing_rows FROM patients
  UNION ALL SELECT 'Duplicate AppointmentID (appointment_registry)', COUNT(*) - COUNT(DISTINCT appointment_id) FROM appointment_registry
  UNION ALL SELECT 'Duplicate DiagnosisID', COUNT(*) - COUNT(DISTINCT diagnosis_id) FROM diagnoses
  UNION ALL SELECT 'Duplicate BillingID', COUNT(*) - COUNT(DISTINCT billing_id) FROM billing
  UNION ALL SELECT 'More than one bill per appointment', COUNT(*) - COUNT(DISTINCT appointment_id) FROM billing
  UNION ALL SELECT 'Appointment with invalid FacilityID', COUNT(*) FROM appointments a WHERE NOT EXISTS (SELECT 1 FROM facilities f WHERE f.facility_id = a.facility_id)
  UNION ALL SELECT 'Appointment with invalid DepartmentID', COUNT(*) FROM appointments a WHERE NOT EXISTS (SELECT 1 FROM departments d WHERE d.department_id = a.department_id)
  UNION ALL SELECT 'Appointment with invalid DoctorID (not a Doctor)', COUNT(*) FROM appointments a WHERE NOT EXISTS (SELECT 1 FROM staff s WHERE s.staff_id = a.doctor_id AND s.staff_type='Doctor')
  UNION ALL SELECT 'Patient with invalid VillageID', COUNT(*) FROM patients p WHERE NOT EXISTS (SELECT 1 FROM villages v WHERE v.village_id = p.village_id)
  UNION ALL SELECT 'Impossible age (<0 or >120)', COUNT(*) FROM patients WHERE age < 0 OR age > 120
  UNION ALL SELECT 'Age not matching date of birth (>1 year vs 2026-01-01)', COUNT(*) FROM patients WHERE ABS(EXTRACT(year FROM age(DATE '2026-01-01', date_of_birth)) - age) > 1
  UNION ALL SELECT 'Invalid billing amount (<= 0)', COUNT(*) FROM billing WHERE amount <= 0
  UNION ALL SELECT 'Payment exceeds bill', COUNT(*) FROM (SELECT b.billing_id FROM billing b JOIN payments p USING (billing_id) GROUP BY b.billing_id, b.amount HAVING SUM(p.amount_paid) > b.amount) x
  UNION ALL SELECT 'Claim exceeds bill', COUNT(*) FROM insurance_claims c JOIN billing b USING (billing_id) WHERE c.claim_amount > b.amount
  UNION ALL SELECT 'Referral to unknown facility', COUNT(*) FROM referrals r WHERE NOT EXISTS (SELECT 1 FROM facilities f WHERE f.facility_id = r.referred_facility_id)
  UNION ALL SELECT 'Referral to the same facility the patient attended (detailed appts)', COUNT(*) FROM referrals r JOIN appointments a USING (appointment_id) WHERE a.facility_id = r.referred_facility_id
  UNION ALL SELECT 'Negative / zero length of stay', COUNT(*) FROM admissions WHERE length_of_stay_days <= 0
  UNION ALL SELECT 'Rating outside 1-5', COUNT(*) FROM patient_feedback WHERE rating NOT BETWEEN 1 AND 5
) t ORDER BY result DESC, check_name;

-- INFO: known integrity limitations carried from the source files (not fixable in SQL)
SELECT 'Appointment IDs in billing but not in appointments' AS finding, COUNT(*) AS records, ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM appointment_registry),1) AS pct
FROM appointment_registry WHERE NOT has_details
UNION ALL SELECT 'Appointments whose DepartmentID does not belong to the appointment FacilityID', COUNT(*), ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM appointments),1) FROM appointments WHERE NOT dept_in_facility
UNION ALL SELECT 'Appointments dated after 22 Oct 2026', COUNT(*), ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM appointments),1) FROM appointments WHERE is_future_dated
UNION ALL SELECT 'Phone numbers stored in scientific notation (unusable)', COUNT(*), ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM patients),1) FROM patients WHERE NOT phone_valid
UNION ALL SELECT 'Bills marked Pending that are fully paid', COUNT(*), ROUND(100.0*COUNT(*)/(SELECT COUNT(*) FROM billing WHERE status='Pending'),1) FROM v_billing WHERE bill_status='Pending' AND outstanding = 0
UNION ALL SELECT 'Beds with status other than Available', COUNT(*), 0 FROM beds WHERE status <> 'Available'
UNION ALL SELECT 'Billing total minus Revenue_Summary total (RWF)', (SELECT SUM(amount) FROM billing)::bigint - (SELECT SUM(revenue) FROM revenue_summary)::bigint, NULL;
