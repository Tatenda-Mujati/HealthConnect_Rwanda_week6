# KPI definitions and values (all values verified by SQL in `SQL/05_kpi_queries.sql`)

Scope rules: **Universe** = 60,000 AppointmentIDs (billing, diagnoses). **Detailed** = the 5,000 appointments with facility/department/doctor/date.

| Category | KPI | Definition | Value |
|---|---|---|---|
| Patient | Total registered patients | rows in Patients | 20,000 |
| Patient | Active patients | Status = Active | 20,000 (every patient is "Active"); 4,443 with a visit |
| Patient | New / returning | patients with 1 / 2+ detailed appointments | 3,933 / 510 |
| Patient | Male vs female | share of patients | 10,090 (50.4%) / 9,910 (49.6%) |
| Patient | Average age | mean Age | 45.03 years |
| Patient | Age 65+ | Age > 65 | 5,487 (27.4%) |
| Patient | Chronic disease | ChronicCondition <> None | 14,929 (74.6%): Asthma 4,996, Hypertension 4,988, Diabetes 4,945 |
| Patient | Insurance coverage | patients with an InsuranceID; bills with a claim | 100%; 70.06% of bills |
| Patient | By province | residence | Western 4,091; Eastern 4,067; Southern 3,967; Kigali City 3,952; Northern 3,923 |
| Appointment | Total appointments | AppointmentIDs in the universe | 60,000 (5,000 with details; Revenue_Summary reports 60,809) |
| Appointment | Daily appointments | detailed appts / active days | 14.88 per day (peak 27) |
| Appointment | Visit types | detailed | Follow-up 1,694; Consultation 1,656; Emergency 1,650 |
| Appointment | Referral rate | referrals / universe | 7.85% (4,708) |
| Appointment | Cancellation rate | not recorded in the data | n/a |
| Appointment | Avg per doctor | 5,000 / 350 doctors | 14.29 |
| Clinical | Diagnoses | 5 conditions, each about 20% | Gastritis 12,208; Diabetes 12,083; Hypertension 12,075; Malaria 11,878; URTI 11,756 |
| Clinical | Severity | | Mild/Moderate/Severe about one third each |
| Clinical | Lab tests / prescriptions | rows | 5,000 / 5,000 (50% of tests abnormal) |
| Clinical | Admission rate | admissions / universe | 8.33% (5,000); 11.7% of detailed appointments |
| Clinical | Average length of stay | mean days | 5.49 days (median 6; 27,438 bed-days) |
| Clinical | Readmission indicator | admitted patients with 2+ admissions (detailed) | 8 of 578 (1.38%) |
| Staff | Doctors / nurses / pharmacists / lab scientists / radiographers / admin | headcount | 350 / 700 / 50 / 40 / 30 / 80 (1,250 total) |
| Staff | Average years of experience | mean | 12.93 years (doctors 13.0, nurses 13.2) |
| Staff | Staff-to-patient ratio | registered patients per staff member | 16.0 (57.1 per doctor) |
| Operational | Facilities | distinct FacilityID | 20 (type/ownership not supplied) |
| Operational | Bed capacity / available | beds | 2,000 / 2,000 (100 per facility) |
| Operational | Bed utilisation | recorded; modelled = bed-days / (beds x 365) | 0% recorded; 3.76% modelled |
| Operational | Equipment | units | 200 (1 per department; 20 per department type) |
| Financial | Total revenue (billed) | sum of Billing.Amount | RWF 9,309,401,961 |
| Financial | Collected / outstanding | payments; billed minus paid | RWF 8,389,454,556 (90.12%) / RWF 919,947,405 |
| Financial | Average billing amount | mean bill | RWF 155,157 |
| Financial | Claim approval rate | Approved / all claims | 49.98% (21,008 of 42,036; the rest Pending, none rejected) |
| Financial | Revenue growth | Revenue_Summary, H2 vs H1 | +2.2%; monthly swings -45% to +109% |
| Experience | Average satisfaction | mean rating | 2.99 / 5 (21,064 responses; 35.1% of appointments) |
| Experience | Rating mix | | 1: 20.2%, 2: 20.3%, 3: 19.9%, 4: 19.9%, 5: 19.7% |
