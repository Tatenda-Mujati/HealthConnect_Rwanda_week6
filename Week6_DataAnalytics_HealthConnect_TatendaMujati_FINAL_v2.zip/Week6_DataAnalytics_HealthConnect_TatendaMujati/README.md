# HealthConnect Rwanda - Healthcare Operations and Performance Analytics Dashboard

**AnalystLab Africa Experience Lab | Week 6 | Track 1: Data Analytics**
Author: Tatenda Mujati (mujatitatenda192@gmail.com)

SQL, Excel-ready outputs and Power BI analysis of the 27 HealthConnect Rwanda source files: 20 facilities, 20,000 patients, 60,000 billed appointments, RWF 9.31 billion billed.

## What is in this submission

| Brief requirement | File(s) |
|---|---|
| PostgreSQL database backup (.sql / .backup) | `Database/healthconnect_backup.sql` (plain SQL) and `Database/healthconnect.backup` (custom format, `pg_restore`) |
| SQL query scripts | `SQL/04_analysis_queries.sql` (the 40 required queries, Q01-Q40), `SQL/05_kpi_queries.sql` (49 KPI queries), `SQL/03_validation_checks.sql` (18 validation checks) |
| Cleaned and validated datasets | `Data/Cleaned/` (27 tables), `Data/Raw/` (27 files exactly as supplied), `Python/clean_data.py` |
| Fully implemented PostgreSQL database | `SQL/01_schema.sql` (27 tables, 30 foreign keys, checks, 3 views), `SQL/02_load_data.sql` |
| Executed query results | `SQL/query_results/Q01-Q40.csv`, `SQL/query_results_kpi/K01-K49.csv` (first 100 rows each) |
| Power BI dashboard (.pbix) | `PowerBI/HealthConnect_Dashboard.pbix` (6 pages: Executive, Clinical, Financial, Operational, Patient experience, Patient). What it contains and the remaining gaps are listed in `PowerBI/Dashboard_Alignment_Notes.md`. Supporting files: `PowerBI_Build_Guide.md`, `DAX_Measures.dax`, `PowerQuery_M_Scripts.pq`, `KPI_Definitions.md`. |
| Executive Dashboard PDF | `Reports/Executive_Dashboard_Preview.pdf` - 6-page preview rendered from the database with the same definitions (not an export of the .pbix). Replace it with File > Export > PDF from the .pbix before submitting if you can. Page images are in `Images/` |
| Business Insights Report (3-5 pages) | `Reports/Business_Insights_Report.pdf` (3 pages) |
| Data Quality / cleaning documentation | `Reports/Data_Quality_Report.pdf`, `Reports/Data_Quality_Findings.csv` (56 findings) |
| Presentation slides (10-15) | `Presentation/Executive_Presentation.pptx` (14 slides) and `.pdf` |
| README.md | this file |
| GitHub repository link | _add your link here_ |

## Reproduce

```bash
# Option A - restore the finished database
createdb healthconnect
psql -d healthconnect -f Database/healthconnect_backup.sql        # or: pg_restore -d healthconnect Database/healthconnect.backup

# Option B - rebuild from the raw files
python3 Python/clean_data.py .                                     # Data/Raw -> Data/Cleaned (needs pandas, openpyxl)
createdb healthconnect && cd SQL
psql -d healthconnect -f 01_schema.sql
psql -d healthconnect -f 02_load_data.sql                          # loads ../Data/Cleaned
psql -d healthconnect -f 03_validation_checks.sql
psql -d healthconnect -f 04_analysis_queries.sql                   # the 40 required queries
```

Everything lives in schema `hc`. `SQL/run_queries.py` re-runs every query and saves the CSV results (edit the `psql` connection line for your server). Both restore paths were tested on PostgreSQL 16: row counts match (60,000 bills, 20,000 patients, 5,000 appointments), and all 89 queries return results identical to the files in this package.

## Headline results

- 20,000 patients: 50.4% male, average age 45.0, 74.6% with asthma, hypertension or diabetes, 27.4% aged over 65.
- Billed RWF 9.31bn; collected RWF 8.39bn (90.1%); outstanding RWF 920m on 11,887 bills.
- Insurance claims: 42,036 (49.98% approved, 21,028 Pending worth RWF 2.44bn, none rejected); 17,964 bills worth RWF 2.80bn have no claim.
- Average patient satisfaction 2.99 / 5; 40.4% of ratings are poor. Differences between facilities (p = 0.79) and departments (p = 0.88) are not significant.
- Workload and staffing are near-uniform across facilities; appointments per doctor range from 12.3 (HF004) to 16.4 (HF013).

## Important notes and assumptions

1. **Appointment coverage.** The Appointments sheet has 5,000 rows, but billing, diagnoses and feedback refer to 60,000 appointment IDs. All 60,000 are kept in `appointment_registry`. Network totals (revenue, diagnoses, claims, feedback) use all 60,000; any split by facility, department, doctor, month, visit type or province uses the 5,000 appointments that have full details and is directional. Rerun the scripts if a full appointment extract is obtained.
2. **No Health Facilities master was supplied.** Facilities appear as HF001-HF020 only; facility type, ownership and location are unavailable. Province is the province of the patient's home village.
3. **Department vs facility.** 95% of appointments list a department that does not belong to their facility, so departments are analysed by name (service line) and facility-by-department views are not used.
4. **Definitions.** Total Appointments = 60,000 distinct appointment IDs (5,000 with details). Total Revenue = amount billed; collected = payments; outstanding = billed minus paid, because Billing.Status contradicts the payments. `Revenue_Summary` (RWF 1.13bn) does not reconcile with billing (RWF 9.31bn) and is used for the monthly trend only.
5. **Not calculable from the data (documented, not invented):** appointment cancellation rate, equipment availability, measured bed or room utilisation (all beds are "Available"; a modelled figure of 3.8% from admissions is reported and labelled), facility type distribution, operating costs, and any facility- or region-level investment ranking.
6. **Other data problems:** phone numbers were saved in scientific notation (only 10 distinct values remain, so duplicate-phone analysis is not meaningful); 30% of ratings contradict their comment; 916 appointments and the Nov-Dec 2026 summary months are dated after the 22 Oct 2026 extraction date (kept and flagged).

See `Reports/Data_Quality_Report.pdf` for the full list of checks and how each was handled.
